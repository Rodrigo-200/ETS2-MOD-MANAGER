#!/usr/bin/env python3
"""
ETS2 Mod Manager - USER VERSION
Automatically installs mod collection
"""

import os
import sys
import json
import shutil
import subprocess
import getpass
import re
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class ETS2Profile:
    name: str
    path: str
    level: int
    xp: int
    mods: int
    workshop_mods: int
    local_mods: int
    last_save: datetime
    storage_type: str

class ETS2ModManager:
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.load_order_file = self.base_dir / "load_order.json"
        self.manifest_file = self.base_dir / "manifest_cache.json"
        
        self.mod_list = []
        self.profiles = []
        self.selected_profile = None
        
        self.load_configuration()

    def load_configuration(self):
        """Load mod configuration"""
        print("📝 Loading mod configuration...")
        
        if self.load_order_file.exists():
            with open(self.load_order_file, 'r', encoding='utf-8') as f:
                self.mod_list = json.load(f)
        
        print(f"✅ Loaded {len(self.mod_list)} mods")

    def scan_profiles(self):
        """Scan for ETS2 profiles"""
        print("🔍 Scanning for ETS2 profiles...")
        
        self.profiles = []
        current_user = getpass.getuser()
        
        locations = [
            f"C:/Users/{current_user}/Documents/Euro Truck Simulator 2/profiles",
            f"C:/Users/{current_user}/OneDrive/Documents/Euro Truck Simulator 2/profiles",
            f"C:/Users/{current_user}/OneDrive/Documentos/Euro Truck Simulator 2/profiles",
        ]
        
        # Add Steam locations
        steam_locations = self._find_steam_locations()
        locations.extend(steam_locations)
        
        for location in locations:
            if os.path.exists(location):
                self._scan_location(location)
        
        self.profiles.sort(key=lambda p: p.mods, reverse=True)
        print(f"✅ Found {len(self.profiles)} profiles")

    def _find_steam_locations(self):
        """Find Steam locations"""
        locations = []
        try:
            import winreg
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam")
            except FileNotFoundError:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam")
            
            steam_path, _ = winreg.QueryValueEx(key, "InstallPath")
            winreg.CloseKey(key)
            
            userdata_path = os.path.join(steam_path, "userdata")
            if os.path.exists(userdata_path):
                for user_id in os.listdir(userdata_path):
                    user_path = os.path.join(userdata_path, user_id)
                    if os.path.isdir(user_path) and user_id.isdigit():
                        ets2_profiles = os.path.join(user_path, "227300", "remote", "profiles")
                        if os.path.exists(ets2_profiles):
                            locations.append(ets2_profiles)
        except:
            pass
        
        return locations

    def _scan_location(self, profiles_path: str):
        """Scan location for profiles"""
        storage_type = "Steam Cloud" if "userdata" in profiles_path else "OneDrive" if "OneDrive" in profiles_path else "Local"
        
        for profile_dir in os.listdir(profiles_path):
            if "(" in profile_dir and ".bak" in profile_dir:
                continue
                
            profile_path = os.path.join(profiles_path, profile_dir)
            if os.path.isdir(profile_path):
                profile = self._read_profile(profile_path, storage_type)
                if profile:
                    self.profiles.append(profile)

    def _read_profile(self, profile_path: str, storage_type: str) -> Optional[ETS2Profile]:
        """Read profile data"""
        try:
            folder_name = os.path.basename(profile_path)
            name = folder_name
            
            # Decode hex names
            hex_names = {
                "3F": "?",
                "4E656E677565": "Nengue",
                "526F63615F757775": "Roca_uwu", 
                "69727569": "irui",
                "526F647269676F": "Rodrigo",
                "526F647269676F20": "Rodrigo "
            }
            
            if folder_name in hex_names:
                name = hex_names[folder_name]
            
            xp = 0
            mod_count = 0
            
            # Count saves
            save_path = os.path.join(profile_path, "save")
            if os.path.exists(save_path):
                mod_count = len([d for d in os.listdir(save_path) if os.path.isdir(os.path.join(save_path, d))])
            
            try:
                last_save = datetime.fromtimestamp(os.path.getmtime(profile_path))
            except:
                last_save = datetime.now()
            
            if name != "Unknown" or mod_count > 0:
                return ETS2Profile(
                    name=name,
                    path=profile_path,
                    level=1,
                    xp=xp,
                    mods=mod_count,
                    workshop_mods=0,
                    local_mods=mod_count,
                    last_save=last_save,
                    storage_type=storage_type
                )
        except:
            pass
        
        return None

    def select_profile(self) -> bool:
        """Select profile for installation"""
        if not self.profiles:
            self.scan_profiles()
        
        if not self.profiles:
            print("❌ No profiles found!")
            return False
        
        print("\n" + "="*50)
        print("SELECT PROFILE FOR MOD INSTALLATION")
        print("="*50)
        
        for i, profile in enumerate(self.profiles, 1):
            print(f"{i}. {profile.name}")
            print(f"   Storage: {profile.storage_type}")
            print(f"   Path: {profile.path}")
            print()
        
        while True:
            try:
                choice = input(f"Select profile (1-{len(self.profiles)}) or 0 to cancel: ").strip()
                if choice == "0":
                    return False
                
                index = int(choice) - 1
                if 0 <= index < len(self.profiles):
                    self.selected_profile = self.profiles[index]
                    print(f"✅ Selected profile: {self.selected_profile.name}")
                    return True
                else:
                    print("❌ Invalid selection!")
            except ValueError:
                print("❌ Please enter a number!")

    def install_mods(self) -> bool:
        """Install mods to selected profile"""
        if not self.selected_profile:
            print("❌ No profile selected!")
            return False
        
        print(f"🚀 Installing {len(self.mod_list)} mods to profile: {self.selected_profile.name}")
        
        profile_file = os.path.join(self.selected_profile.path, "profile.sii")
        
        try:
            # Create backup
            backup_file = profile_file + ".backup"
            if os.path.exists(profile_file):
                shutil.copy2(profile_file, backup_file)
                print(f"✅ Created backup: {backup_file}")
            
            # Create new SII structure
            profile_name = self.selected_profile.name
            sii_content = f"""SiiNunit
{{

profile_data : profile.data {{
 profile_name: "{profile_name}"
 company_name: "{profile_name}"
 experience: 1000
 money_account: 500000
 
 active_mods: {len(self.mod_list)}
"""
            
            # Add all mods
            for i, mod in enumerate(self.mod_list):
                sii_content += f' active_mods[{i}]: "{mod}"\n'
            
            # Close structure
            sii_content += """
 user_data[0]: ff_data
}}

}}
"""
            
            # Write new profile
            with open(profile_file, 'w', encoding='utf-8') as f:
                f.write(sii_content)
            
            print(f"🎮 Successfully installed {len(self.mod_list)} mods!")
            print("ℹ️  ETS2 will handle file encoding when you next run the game")
            return True
            
        except Exception as e:
            print(f"❌ Error installing mods: {e}")
            return False

    def run(self):
        """Run the mod manager"""
        print("🚛 ETS2 Mod Manager - User Version")
        print("="*50)
        
        if not self.mod_list:
            print("❌ No mods loaded!")
            return
        
        print(f"📦 Ready to install {len(self.mod_list)} mods")
        print()
        
        if self.select_profile():
            confirm = input("\nInstall mods? (y/n): ").strip().lower()
            if confirm == 'y':
                if self.install_mods():
                    print("\n✅ Installation completed successfully!")
                else:
                    print("\n❌ Installation failed!")
            else:
                print("\n❌ Installation cancelled")
        
        input("\nPress Enter to exit...")

if __name__ == "__main__":
    manager = ETS2ModManager()
    manager.run()
